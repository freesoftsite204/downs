using UnityEngine;

[System.Serializable]
public class Dialogue
{
    public string name; // Nom du personnage qui parle

    [TextArea(3, 10)] // Donne une zone de texte plus grande dans l'inspecteur
    public string[] sentences; // Liste des répliques
}