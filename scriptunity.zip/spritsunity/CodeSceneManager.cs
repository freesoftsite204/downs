using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
using TMPro; // À utiliser si tu as installé TextMeshPro (recommandé)

public class CodeSceneManager : MonoBehaviour
{
    [Header("Configuration")]
    public string codeCorrect = "1234"; // Le code à trouver
    public string nomDeLaSceneACharger;

    [Header("Éléments UI")]
    public TMP_InputField inputField; // Change en InputField si tu n'utilises pas TMP
    public Text errorText; // Message en cas d'erreur

    void Start()
    {
        errorText.text = ""; // Cache le message au début
    }

    public void VerifierCode()
    {
        if (inputField.text == codeCorrect)
        {
            SceneManager.LoadScene(nomDeLaSceneACharger);
        }
        else
        {
            errorText.text = "Code incorrect !";
            inputField.text = ""; // Efface l'entrée
        }
    }
}