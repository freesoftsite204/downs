using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Platformer.Gameplay;
using static Platformer.Core.Simulation;
using Platformer.Model;
using Platformer.Core;
using UnityEngine.InputSystem;

namespace Platformer.Mechanics
{
    /// <summary>
    /// Contrôleur dédié au Joueur 2 (Manette 2 uniquement).
    /// Hérite de PlayerController pour assurer la compatibilité avec les événements Simulation.
    /// </summary>
    public class PlayerPlatformer2 : PlayerController
    {
        [Header("Audio")]
        public AudioClip attackSoundClip;
        public AudioClip kickSoundClip;
        public AudioClip jumpAudio;
        public AudioClip respawnAudio;
        public AudioClip ouchAudio;

        [Header("Player Settings")]
        public float maxSpeed = 7f;
        public float jumpTakeOffSpeed = 7f;

        [Header("Attack Settings")]
        public float attack1Radius = 2f;
        public float attack4Radius = 5f;
        public float attackCooldown = 0.35f; // anti-spam

        [Header("Knockback")]
        [SerializeField] private float knockbackForce = 10f;
        [SerializeField] private float stunDuration = 0.5f;

        public JumpState jumpState = JumpState.Grounded;
        public Collider2D collider2d;
        public AudioSource audioSource;
        public Health health;

        public bool controlEnabled = true;

        public Bounds Bounds => collider2d != null ? collider2d.bounds : new Bounds();

        // Privés
        private bool stopJump;
        private bool jump;
        private Vector2 move;
        private SpriteRenderer spriteRenderer;
        internal Animator animator;
        private float lastAttackTime = -10f;

        // Référence dédiée à la deuxième manette
        private Gamepad player2Gamepad;

        // Buffer pré-alloué pour optimiser la mémoire lors des attaques (max 16 cibles à la fois)
        private readonly Collider2D[] hitBuffer = new Collider2D[16];

        readonly PlatformerModel model = Simulation.GetModel<PlatformerModel>();

        void Awake()
        {   
            // Tag spécifique pour le joueur 2
            gameObject.tag = "Player2";

            health = GetComponent<Health>();
            audioSource = GetComponent<AudioSource>();
            collider2d = GetComponent<Collider2D>();
            spriteRenderer = GetComponent<SpriteRenderer>();
            animator = GetComponent<Animator>();
        }

        void OnEnable()
        {
            InputSystem.onDeviceChange += OnDeviceChange;
            AssignGamepad2();
        }

        void OnDisable()
        {
            InputSystem.onDeviceChange -= OnDeviceChange;
        }

        /// <summary>
        /// Écoute les branchements/débranchements de manettes en temps réel.
        /// </summary>
        private void OnDeviceChange(InputDevice device, InputDeviceChange change)
        {
            if (device is Gamepad)
            {
                AssignGamepad2();
            }
        }

        /// <summary>
        /// Recherche spécifiquement la DEUXIÈME manette dans le système.
        /// </summary>
        private void AssignGamepad2()
        {
            var gamepads = Gamepad.all;

            if (gamepads.Count > 1)
            {
                player2Gamepad = gamepads[1];
            }
            else
            {
                player2Gamepad = null;
            }
        }

        protected override void Update()
        {
            // Exécute les contrôles UNIQUEMENT si la manette 2 est présente
            if (controlEnabled && player2Gamepad != null && player2Gamepad.added)
            {
                // --- DÉPLACEMENT & SAUT (Manette 2) ---
                move.x = player2Gamepad.leftStick.x.ReadValue();

                // Bouton A / Croix (Manette 2)
                if (jumpState == JumpState.Grounded && player2Gamepad.buttonSouth.wasPressedThisFrame)
                {
                    jumpState = JumpState.PrepareToJump;
                }
                else if (player2Gamepad.buttonSouth.wasReleasedThisFrame)
                {
                    stopJump = true;
                    Schedule<PlayerStopJump>().player = this;
                }

                // --- ATTAQUES (Manette 2) ---
                if (Time.time >= lastAttackTime + attackCooldown)
                {
                    // Bouton X / Carré DE LA MANETTE 2
                    if (player2Gamepad.buttonWest.wasPressedThisFrame)
                    {
                        ExecuteAttack("Attack", attack1Radius, attackSoundClip);
                    }

                    // Bouton Y / Triangle DE LA MANETTE 2
                    if (player2Gamepad.buttonNorth.wasPressedThisFrame)
                    {
                        ExecuteAttack("Kick", attack4Radius, kickSoundClip);
                    }
                }
            }
            else
            {
                move.x = 0;
            }

            UpdateJumpState();
            base.Update();
        }

        private void ExecuteAttack(string animTrigger, float attackRadius, AudioClip attackAudio)
        {
            lastAttackTime = Time.time;

            if (animator != null)
                animator.SetTrigger(animTrigger);

            if (audioSource != null && attackAudio != null)
                audioSource.PlayOneShot(attackAudio);

            // Utilisation d'OverlapCircleNonAlloc pour éviter les allocations inutiles de mémoire
            int hitCount = Physics2D.OverlapCircleNonAlloc(transform.position, attackRadius, hitBuffer);

            for (int i = 0; i < hitCount; i++)
            {
                Collider2D col = hitBuffer[i];

                // Ignore son propre collider
                if (col.gameObject == this.gameObject) continue;

                // Ignore le Joueur 1 (Tag "Player")
                if (col.CompareTag("Player")) continue;

                // Ennemi normal
                if (col.CompareTag("Enemy"))
                {
                    Animator enemyAnim = col.GetComponent<Animator>();
                    if (enemyAnim != null)
                        enemyAnim.SetTrigger("destroy");

                    if (audioSource != null && ouchAudio != null)
                        audioSource.PlayOneShot(ouchAudio);

                    col.enabled = false;
                    Destroy(col.gameObject, 0.5f);
                }
                // Boss
                else if (col.CompareTag("Boss"))
                {
                    if (ApplyDamageToBoss(col))
                    {
                        Animator bossAnim = col.GetComponent<Animator>();
                        if (bossAnim != null)
                        {
                            bossAnim.SetTrigger("ouch");
                            bossAnim.SetTrigger("destroy");
                        }

                        Rigidbody2D rb = col.GetComponent<Rigidbody2D>();
                        if (rb != null)
                        {
                            Vector2 knockbackDirection = (col.transform.position - transform.position).normalized;

                            if (knockbackDirection == Vector2.zero)
                            {
                                knockbackDirection = Vector2.up;
                            }

                            rb.velocity = knockbackDirection * knockbackForce;
                        }

                        if (audioSource != null && ouchAudio != null)
                            audioSource.PlayOneShot(ouchAudio);
                    }
                }
            }
        }

        private bool ApplyDamageToBoss(Collider2D enemy)
        {
            // 1. Essaye d'abord d'accéder au composant Health natif s'il existe
            Health bossHealth = enemy.GetComponent<Health>();
            if (bossHealth != null)
            {
                bossHealth.Decrement();
                return true;
            }

            // 2. Si le Boss possède une interface personnalisée IDamageable
            IDamageable damageable = enemy.GetComponent<IDamageable>();
            if (damageable != null)
            {
                damageable.TakeDamage(1);
                return true;
            }

            Debug.LogWarning($"Boss détecté ({enemy.name}) mais aucun composant de santé compatible trouvé !");
            return false;
        }

        void UpdateJumpState()
        {
            jump = false;

            switch (jumpState)
            {
                case JumpState.PrepareToJump:
                    jumpState = JumpState.Jumping;
                    jump = true;
                    stopJump = false;
                    break;

                case JumpState.Jumping:
                    if (!IsGrounded)
                    {
                        Schedule<PlayerJumped>().player = this;
                        jumpState = JumpState.InFlight;
                    }
                    break;

                case JumpState.InFlight:
                    if (IsGrounded)
                    {
                        Schedule<PlayerLanded>().player = this;
                        jumpState = JumpState.Landed;
                    }
                    break;

                case JumpState.Landed:
                    jumpState = GroundedState();
                    break;
            }
        }

        private JumpState GroundedState()
        {
            return JumpState.Grounded;
        }

        protected override void ComputeVelocity()
        {
            if (jump && IsGrounded)
            {
                velocity.y = jumpTakeOffSpeed * model.jumpModifier;
                jump = false;
            }
            else if (stopJump)
            {
                stopJump = false;
                if (velocity.y > 0)
                    velocity.y *= model.jumpDeceleration;
            }

            // Flip du sprite
            if (move.x > 0.01f)
                spriteRenderer.flipX = false;
            else if (move.x < -0.01f)
                spriteRenderer.flipX = true;

            if (animator != null)
            {
                animator.SetBool("grounded", IsGrounded);
                animator.SetFloat("velocityX", Mathf.Abs(velocity.x) / maxSpeed);
            }

            targetVelocity = move * maxSpeed;
        }

        private void OnDrawGizmosSelected()
        {
            Gizmos.color = Color.red;
            Gizmos.DrawWireSphere(transform.position, attack1Radius);

            Gizmos.color = Color.yellow;
            Gizmos.DrawWireSphere(transform.position, attack4Radius);
        }

        public enum JumpState
        {
            Grounded,
            PrepareToJump,
            Jumping,
            InFlight,
            Landed
        }
    }

    /// <summary>
    /// Optionnel : Interface recommandable pour gérer les dégâts proprement sur vos scripts Boss/Ennemis.
    /// </summary>
    public interface IDamageable
    {
        void TakeDamage(int amount);
    }
}