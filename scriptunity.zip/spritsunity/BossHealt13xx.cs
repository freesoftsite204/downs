using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI; // <--- NE PAS OUBLIER : Nécessaire pour manipuler l'UI

public class BossHealth13xx : MonoBehaviour
{
    [Header("Paramètres de Santé")]
    public int maxHealth = 3;
    public int currentHealth;

    [Header("UI")]
    public Slider healthSlider; // Faites glisser votre Slider ici dans l'inspecteur

    private void Start()
    {
        currentHealth = maxHealth;
        
        // Initialisation de la barre de vie
        if (healthSlider != null)
        {
            healthSlider.maxValue = maxHealth;
            healthSlider.value = maxHealth;
        }
    }

    private void OnTriggerEnter2D(Collider2D other)
    {
        if (other.CompareTag("Enemy"))
        {
            TakeDamage(1);
        }
    }

    public void TakeDamage(int damage)
    {
        currentHealth -= damage;
        
        // Mise à jour visuelle de la barre
        if (healthSlider != null)
        {
            healthSlider.value = currentHealth;
        }

        if (currentHealth <= 0)
        {
            Die();
        }
    }

   void Die()
    {
        SceneManager.LoadScene("darknightvsboss3");
    }
}
