using System.Runtime.CompilerServices;
using UnityEngine;

public class AudioManager : MonoBehaviour
{
[Header("-------- Audio Source --------")] // Start is called once before the first execution of Update after the MonoBehaviour is created
[SerializeField] AudioSource musicSource;
[Header("-------- Audio Clip --------")]
public AudioClip background;

private void Start()
    {
        musicSource.clip = background;
    
        musicSource.Play();}
}
