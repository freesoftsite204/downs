using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class BossHealth55 : MonoBehaviour
{
    [Header("Paramètres de Santé")]
    public int maxHealth = 3;
    public int currentHealth;

    [Header("UI")]
    public Slider healthSlider; // À glisser dans l'Inspecteur

    private void Start()
    {
        currentHealth = maxHealth;
        
        // Initialisation du Slider
        if (healthSlider != null)
        {
            healthSlider.maxValue = maxHealth;
            healthSlider.value = currentHealth;
        }
    }

    private void OnTriggerEnter2D(Collider2D other)
    {
        // Détecte la collision avec l'ennemi (ou le projectile)
        if (other.CompareTag("Enemy"))
        {
            TakeDamage(1);
            
            // Optionnel : Détruit l'objet qui a touché le boss
            // Destroy(other.gameObject); 
        }
    }

    public void TakeDamage(int damage)
    {
        currentHealth -= damage;
        
        // Mise à jour de l'UI
        if (healthSlider != null)
        {
            healthSlider.value = currentHealth;
        }

        // Vérification de la mort
        if (currentHealth <= 0)
        {
            Die();
        }
    }

    private void Die()
    {
        // Charge la scène souhaitée
        SceneManager.LoadScene("playervsboss2");
    }
}