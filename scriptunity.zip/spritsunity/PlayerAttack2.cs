using UnityEngine;

public class PlayerAttack2 : MonoBehaviour
{
    // Variables nécessaires au bon fonctionnement du script
    [SerializeField] private Animator animator;
    [SerializeField] private AudioClip respawnAudio;
    public AudioSource audioSource;
    // Glisse ton fichier audio (le bruit de l'attaque) ici
    public AudioClip soundClip;
    // Utilisation simple de Start() pour un MonoBehaviour classique
    private void Start()
    {
        // Si l'animator n'est pas assigné dans l'inspecteur, on essaie de le récupérer
        if (animator == null)
        {
            animator = GetComponent<Animator>();
        }
    }

    // CORRECTION : Suppression de "protected override" car MonoBehaviour n'a pas de Update() virtuel
    private void Update()
    {
        if (Input.GetKeyDown(KeyCode.JoystickButton6))
        {
            if (animator != null)
            {
                animator.SetTrigger("Ice");
            }
            if (audioSource != null && soundClip != null)
            {
                // PlayOneShot permet de jouer le son sans couper une autre instance du son si tu appuies vite
                audioSource.PlayOneShot(soundClip);
            }
            
            Debug.Log("Bouton pressé (Mode 2D) !");

            // On utilise OverlapCircle pour la 2D
            // transform.position est le centre, 2f est le rayon de détection
            Collider2D[] hitEnemies = Physics2D.OverlapCircleAll(transform.position, 5f);

            foreach (Collider2D enemy in hitEnemies)
            {
                if (enemy.CompareTag("Enemy"))
                {
                    // 1. Récupérer l'animator de l'ennemi
                    Animator enemyAnim = enemy.GetComponent<Animator>();
                    if (enemyAnim != null)
                    {
                        enemyAnim.SetTrigger("destroy");
                        enemyAnim.SetTrigger("destr");
                    }

                    // 2. Jouer le son sur le joueur
                    GameObject player = GameObject.FindGameObjectWithTag("Player");
                    if (player != null)
                    {
                        AudioSource audioSourceDuJoueur = player.GetComponent<AudioSource>();
                        if (audioSourceDuJoueur != null && respawnAudio != null)
                        {
                            audioSourceDuJoueur.PlayOneShot(respawnAudio);
                        }
                    }

                    // 3. Détruire l'objet APRES un délai (ex: 0.5 secondes)
                    // On désactive le collider pour éviter que l'ennemi "mort" ne gène encore
                    enemy.enabled = false; 
                    Destroy(enemy.gameObject, 0.5f); 
                }
            }
        }
    }
}