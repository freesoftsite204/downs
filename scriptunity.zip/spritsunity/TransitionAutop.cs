using UnityEngine;
using UnityEngine.SceneManagement;

public class TransitionAutop : MonoBehaviour
{
    [Header("Configuration")]
    [SerializeField] private string playervsdarknight = "playervsdarknight"; // Nom exact de la scène suivante
    [SerializeField] private float tempsAttente = 7f;        // Temps en secondes

    void Start()
    {
        // On lance le compte à rebours dès que la scène de transition apparaît
        Invoke("ChangerDeScene", tempsAttente);
    }

    void ChangerDeScene()
    {
        SceneManager.LoadScene("playervsdarknight");
    }
}
