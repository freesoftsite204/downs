using UnityEngine;

public class Bullet : MonoBehaviour
{
    [Header("Paramètres de combat")]
    public int damage = 1; // Dégâts réglables dans l'inspecteur

    void OnTriggerEnter2D(Collider2D hitInfo)
    {
        // Ennemis classiques
        if (hitInfo.CompareTag("Enemy"))
        {
            Destroy(hitInfo.gameObject);
            Destroy(gameObject);
            return;
        }

        // Boss
        if (hitInfo.CompareTag("Boss"))
        {
            // On cherche le script de vie du boss (sur l'objet ou un parent)
            BossHealth2 bossHealth = hitInfo.GetComponent<BossHealth2>();
            if (bossHealth == null)
                bossHealth = hitInfo.GetComponentInParent<BossHealth2>();

            if (bossHealth != null)
            {
                bossHealth.TakeDamage(damage);
            }
            else
            {
                Debug.LogWarning("Boss touché mais aucun script BossHealth2 trouvé !");
            }

            // On détruit uniquement la balle (pas le boss)
            Destroy(gameObject);
            return;
        }

        // Obstacles / murs
        if (hitInfo.CompareTag("Obstacle"))
        {
            Destroy(gameObject);
        }
    }
}