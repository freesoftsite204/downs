using UnityEngine;

public class PlayerAttack4 : MonoBehaviour
{
    // Variables nécessaires au bon fonctionnement du script
    [SerializeField] private Animator animator;
    [SerializeField] private AudioClip respawnAudio;
    public AudioSource audioSource;
    // Glisse ton fichier audio (le bruit de l'attaque) ici
    public AudioClip soundClip;

    private void Start()
    {
        // Si l'animator n'est pas assigné dans l'inspecteur, on essaie de le récupérer
        if (animator == null)
        {
            animator = GetComponent<Animator>();
        }
    }

    private void Update()
    {
        // KeyCode.JoystickButton1 correspond au bouton B sur une manette Xbox
        if (Input.GetKeyDown(KeyCode.Joystick2Button2))
        {
            if (animator != null)
            {
                // Déclenchement du trigger "Kick" (avec la majuscule)
                animator.SetTrigger("Attack1");
            }

            if (audioSource != null && soundClip != null)
            {
                // PlayOneShot permet de jouer le son sans couper une autre instance
                audioSource.PlayOneShot(soundClip);
            }
            
            Debug.Log("Bouton B pressé (Coup de pied) !");

            // Détection des ennemis aux alentours (rayon de 5 unités)
            Collider2D[] hitEnemies = Physics2D.OverlapCircleAll(transform.position, 5f);

            foreach (Collider2D enemy in hitEnemies)
            {
                if (enemy.CompareTag("Enemy"))
                {
                    // 1. Récupérer l'animator de l'ennemi
                    Animator enemyAnim = enemy.GetComponent<Animator>();
                    if (enemyAnim != null)
                    {
                        enemyAnim.SetTrigger("destroy");
                        enemyAnim.SetTrigger("destr");
                    }

                    // 2. Jouer le son sur le joueur
                    GameObject player = GameObject.FindGameObjectWithTag("Player");
                    if (player != null)
                    {
                        AudioSource audioSourceDuJoueur = player.GetComponent<AudioSource>();
                        if (audioSourceDuJoueur != null && respawnAudio != null)
                        {
                            audioSourceDuJoueur.PlayOneShot(respawnAudio);
                        }
                    }

                    // 3. Désactiver le collider et détruire l'ennemi après 0,5s
                    enemy.enabled = false; 
                    Destroy(enemy.gameObject, 0.5f); 
                }
            }
        }
    }
}