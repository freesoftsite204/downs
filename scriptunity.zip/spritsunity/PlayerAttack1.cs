using System.Collections;
using UnityEngine;
using TMPro;

public class PlayerAttack1 : MonoBehaviour
{
    // Variables d'animation, audio et UI
    [SerializeField] private Animator animator;
    [SerializeField] private AudioClip respawnAudio;
    [SerializeField] private AudioClip soundClip;
    [SerializeField] private AudioClip ouchAudio;
    public AudioSource audioSource;
    [SerializeField] private TextMeshProUGUI comboText; // Texte UI pour le "3 HIT COMBO"

    // Paramètres de combat
    [SerializeField] private float attackRadius = 5f;
    [SerializeField] private float knockbackForce = 4f;

    // Gestion du temps max entre 2 attaques du combo
    [SerializeField] private float comboWindow = 1.0f;
    private float lastHitTime;
    private int comboStep = 0;

    private bool isInvincible = false;

    private void Start()
    {
        if (animator == null)
        {
            animator = GetComponent<Animator>();
        }

        if (audioSource == null)
        {
            audioSource = GetComponent<AudioSource>();
        }

        if (comboText != null)
        {
            comboText.gameObject.SetActive(false);
        }
    }

    private void Update()
    {
        // Réinitialise le combo si le joueur met trop de temps entre deux touches
        if (comboStep > 0 && Time.time - lastHitTime > comboWindow)
        {
            ResetCombo();
        }

        // Étape 1 : Touche X (JoystickButton2)
        if (comboStep == 0 && Input.GetKeyDown(KeyCode.JoystickButton2))
        {
            AdvanceCombo(1, "light");
        }
        // Étape 2 : Touche Y (JoystickButton3)
        else if (comboStep == 1 && Input.GetKeyDown(KeyCode.JoystickButton3))
        {
            AdvanceCombo(2, "light");
        }
        // Étape 3 : Touche B (JoystickButton1)
        else if (comboStep == 2 && Input.GetKeyDown(KeyCode.JoystickButton1))
        {
            AdvanceCombo(3, "light");
            ResetCombo(); // Réinitialise le combo après la 3e frappe
        }
    }

    private void AdvanceCombo(int step, string animTrigger)
    {
        comboStep = step;
        lastHitTime = Time.time;

        // Déclenche l'animation
        if (animator != null)
        {
            animator.SetTrigger(animTrigger);
        }

        // Exécute la logique de frappe/dégâts
        ExecuteAttack();
    }

    private void ResetCombo()
    {
        comboStep = 0;
    }

    private void ShowComboUI()
    {
        if (comboText != null)
        {
            comboText.text = "3 HIT COMBO !";
            comboText.gameObject.SetActive(true);
            CancelInvoke(nameof(HideComboUI));
            Invoke(nameof(HideComboUI), 1.5f);
        }
    }

    private void HideComboUI()
    {
        if (comboText != null)
        {
            comboText.gameObject.SetActive(false);
        }
    }

    private IEnumerator InvincibilityRoutine(float duration)
    {
        isInvincible = true;
        yield return new WaitForSeconds(duration);
        isInvincible = false;
    }

    private void ExecuteAttack()
    {
        if (audioSource != null && soundClip != null)
        {
            audioSource.PlayOneShot(soundClip);
        }

        Debug.Log($"Attaque exécutée ! (Étape du combo : {comboStep})");

        Collider2D[] hitEnemies = Physics2D.OverlapCircleAll(transform.position, attackRadius);
        bool hitAnything = false;

        foreach (Collider2D hit in hitEnemies)
        {
            // --- Ennemi classique ---
            if (hit.CompareTag("Enemy"))
            {
                hitAnything = true;

                Animator enemyAnim = hit.GetComponent<Animator>();
                if (enemyAnim != null)
                {
                    enemyAnim.SetTrigger("destroy");
                }

                if (audioSource != null && respawnAudio != null)
                {
                    audioSource.PlayOneShot(respawnAudio);
                }

                hit.enabled = false; 
                Destroy(hit.gameObject, 0.5f); 
            }
            // --- Boss ---
            else if (hit.CompareTag("Boss"))
            {
                hitAnything = true;

                if (ApplyDamageToBoss(hit))
                {
                    Animator bossAnim = hit.GetComponent<Animator>();

                    if (bossAnim != null)
                    {
                        bossAnim.SetTrigger("hurt3");
                    }

                    hit.SendMessage("StunBoss", 2.5f, SendMessageOptions.DontRequireReceiver);
                }

                StartCoroutine(InvincibilityRoutine(5.5f));

                Rigidbody2D rb = hit.GetComponent<Rigidbody2D>();
                if (rb != null)
                {
                    Vector2 knockbackDirection = (hit.transform.position - transform.position).normalized;

                    if (knockbackDirection == Vector2.zero)
                    {
                        knockbackDirection = Vector2.up;
                    }

                    rb.velocity = knockbackDirection * knockbackForce;
                }

                if (audioSource != null && ouchAudio != null)
                {
                    audioSource.PlayOneShot(ouchAudio);
                }
            }
        }

        // Affiche le UI du combo uniquement si c'est la 3e étape ET qu'au moins une cible a été touchée
        if (comboStep == 3 && hitAnything)
        {
            ShowComboUI();
        }
    }

    private bool ApplyDamageToBoss(Collider2D enemy)
    {
        var components = enemy.GetComponents<MonoBehaviour>();
        foreach (var comp in components)
        {
            var method = comp.GetType().GetMethod("TakeDamage", new[] { typeof(int) });
            if (method != null)
            {
                method.Invoke(comp, new object[] { 1 });
                return true;
            }
        }

        Debug.LogWarning("Boss détecté mais aucun script avec TakeDamage(int) trouvé !");
        return false;
    }

    private void OnDrawGizmosSelected()
    {
        Gizmos.color = Color.red;
        Gizmos.DrawWireSphere(transform.position, attackRadius);
    }
}