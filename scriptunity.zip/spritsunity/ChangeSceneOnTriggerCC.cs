using UnityEngine;
using UnityEngine.SceneManagement;

public class ChangeSceneOnTriggerCC : MonoBehaviour
{
    // Nom de la scène vers laquelle basculer
    public string niveau1;

    private void OnTriggerEnter2D(Collider2D other)
    {
        // Vérifie que c’est bien le joueur
        if (other.CompareTag("Player"))
        {
            SceneManager.LoadScene("level3a");
        }
    }
}
