using System.Collections;
using UnityEngine;

// Force Unity à ajouter un composant AudioSource sur le PNJ pour éviter les erreurs
[RequireComponent(typeof(AudioSource))]
public class AffichageTextePNJ : MonoBehaviour
{
    [Header("Configuration UI")]
    public GameObject textCanvas; 

    [Header("Configuration Audio")]
    // Glisse ton fichier audio/voix ici dans l'Inspector
    public AudioClip voixPNJ; 
    private AudioSource audioSource;

    [Header("Réglages")]
    public float tempsAffichage = 5f; 

    private Coroutine chronometreTexte;

    void Start()
    {
        // On récupère le composant AudioSource attaché au PNJ
        audioSource = GetComponent<AudioSource>();

        if (textCanvas != null)
        {
            textCanvas.SetActive(false);
        }
    }

    private void OnTriggerEnter2D(Collider2D other)
    {
        if (other.CompareTag("Player"))
        {
            if (textCanvas != null)
            {
                if (chronometreTexte != null)
                {
                    StopCoroutine(chronometreTexte);
                }

                // Affiche le texte
                textCanvas.SetActive(true); 

                // Joue la voix si un fichier audio a été fourni
                if (voixPNJ != null && audioSource != null)
                {
                    audioSource.clip = voixPNJ;
                    audioSource.Play();
                }
                
                chronometreTexte = StartCoroutine(CacherTexteApresDelai());
            }
        }
    }

    private void OnTriggerExit2D(Collider2D other)
    {
        if (other.CompareTag("Player"))
        {
            if (chronometreTexte != null)
            {
                StopCoroutine(chronometreTexte);
            }

            if (textCanvas != null)
            {
                textCanvas.SetActive(false);
            }

            // Optionnel : Coupe la voix si le joueur s'en va pendant qu'elle parle
            if (audioSource != null && audioSource.isPlaying)
            {
                audioSource.Stop();
            }
        }
    }

    private IEnumerator CacherTexteApresDelai()
    {
        yield return new WaitForSeconds(tempsAffichage);
        
        if (textCanvas != null)
        {
            textCanvas.SetActive(false);
        }

        // Optionnel : Coupe la voix quand le temps est écoulé
        if (audioSource != null && audioSource.isPlaying)
        {
            audioSource.Stop();
        }
    }
}