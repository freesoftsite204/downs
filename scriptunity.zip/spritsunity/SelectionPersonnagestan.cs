using UnityEngine;
using UnityEngine.SceneManagement;

public class SelectionPersonnagestan : MonoBehaviour
{
    [Header("Configuration des Personnages")]
    [SerializeField] private GameObject[] personnages; // Glissez vos prefabs ou objets 3D/2D ici
    
    private int indexActuel = 0;

    void Start()
    {
        // Désactive tous les personnages au départ, sauf le premier
        ActualiserAffichage();
    }

    // Appelé par le bouton "Suivant"
    public void Suivant()
    {
        personnages[indexActuel].SetActive(false);
        
        indexActuel++;
        if (indexActuel >= personnages.Length)
        {
            indexActuel = 0; // Revient au début
        }

        ActualiserAffichage();
    }

    // Appelé par le bouton "Précédent"
    public void Precedent()
    {
        personnages[indexActuel].SetActive(false);
        
        indexActuel--;
        if (indexActuel < 0)
        {
            indexActuel = personnages.Length - 1; // Va au dernier
        }

        ActualiserAffichage();
    }

    // Active le personnage actuellement sélectionné
    private void ActualiserAffichage()
    {
        if (personnages.Length > 0)
        {
            personnages[indexActuel].SetActive(true);
        }
    }

    // Appelé par le bouton "Valider"
    public void ValiderSelection()
    {
        // Sauvegarde l'index du personnage pour le récupérer dans la prochaine scène
        PlayerPrefs.SetInt("PersonnageChoisi", indexActuel);
        PlayerPrefs.Save();

        // Remplacez "SceneJeu" par le nom exact de votre scène de jeu
        SceneManager.LoadScene("vredwarriorvsblacknight");
    }
}