using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Platformer.Gameplay;
using static Platformer.Core.Simulation;
using Platformer.Model;
using Platformer.Core;

namespace Platformer.Mechanics
{
    public class EnemyAIController : KinematicObject
    {
        [Header("AI Settings")]
        public float maxSpeed = 3.5f;           
        public float attackDistance = 2f;       
        public float targetDetectionRadius = 10f; 
        public float attackDamageRadius = 2f;   
        public int damageAmount = 1;            

        [Header("Attack & Defense Settings")]
        public float timeBetweenAttacks = 1.5f; // Temps en secondes entre chaque action
        [Range(0f, 1f)]
        public float blockChance = 0.15f;       // Chance de bloquer (15% par défaut)
        private float nextAttackTime = 0f;      // Chronomètre interne

        [Header("Audio Settings")]
        public AudioSource audioSource;
        public AudioClip[] attackVoices;        // Vos clips vocaux à assigner dans l'Inspecteur

        private Transform playerTransform;
        private SpriteRenderer spriteRenderer;
        private Animator animator;
        private Vector2 move;

        // Triggers mis à jour : bossAttack1, bossAttack2, bossAttack3
        private List<string> availableAttacks = new List<string> { "bossAttack1", "bossAttack2", "bossAttack3" };
        private string lastAttack = "";

        void Awake()
        {
            spriteRenderer = GetComponent<SpriteRenderer>();
            animator = GetComponent<Animator>();

            if (audioSource == null)
            {
                audioSource = GetComponent<AudioSource>();
            }
        }

        protected override void Update()
        {
            if (playerTransform == null)
            {
                GameObject playerObj = GameObject.FindGameObjectWithTag("Player");
                if (playerObj != null)
                {
                    playerTransform = playerObj.transform;
                }
            }

            if (playerTransform != null)
            {
                float distanceToPlayer = Vector2.Distance(transform.position, playerTransform.position);

                // Phase de poursuite
                if (distanceToPlayer <= targetDetectionRadius && distanceToPlayer > attackDistance)
                {
                    // Désactive le blocage pendant le déplacement
                    if (animator != null) animator.SetBool("idleBlock", false);

                    float direction = playerTransform.position.x > transform.position.x ? 1f : -1f;
                    move.x = direction;
                }
                // Phase de combat
                else
                {
                    move.x = 0; // S'arrêter pour agir

                    if (distanceToPlayer <= attackDistance && Time.time >= nextAttackTime)
                    {
                        // Bloque rarement
                        if (Random.value < blockChance)
                        {
                            PerformBlock();
                        }
                        else
                        {
                            TriggerAlternatingAttack();
                        }

                        nextAttackTime = Time.time + timeBetweenAttacks;
                    }
                }
            }
            else
            {
                move.x = 0;
            }

            base.Update();
        }

        void PerformBlock()
        {
            if (animator != null)
            {
                animator.SetBool("idleBlock", true);
            }
            Debug.Log("Le Boss bloque !");
        }

        void TriggerAlternatingAttack()
        {
            if (animator != null)
            {
                // Désactive le blocage
                animator.SetBool("idleBlock", false);
            }

            // Sélectionne une attaque sans répéter la précédente
            List<string> validAttacks = new List<string>(availableAttacks);
            if (!string.IsNullOrEmpty(lastAttack) && validAttacks.Count > 1)
            {
                validAttacks.Remove(lastAttack);
            }

            string chosenAttack = validAttacks[Random.Range(0, validAttacks.Count)];
            lastAttack = chosenAttack;

            if (animator != null)
            {
                animator.SetTrigger(chosenAttack);
                Debug.Log($"Le Boss lance {chosenAttack} !");
            }

            PlayAttackVoice();

            // Application immédiate des dégâts communs à toutes les attaques
            ApplyDamage();
        }

        // Système de dégâts unique partagé par toutes les attaques
        public void ApplyDamage()
        {
            Collider2D[] hitPlayers = Physics2D.OverlapCircleAll(transform.position, attackDamageRadius);

            foreach (Collider2D playerCollider in hitPlayers)
            {
                if (playerCollider.CompareTag("Player"))
                {
                    PlayerHealth playerHealth = playerCollider.GetComponent<PlayerHealth>();
                    if (playerHealth != null)
                    {
                        playerHealth.TakeDamage(damageAmount);
                    }

                    Animator playerAnim = playerCollider.GetComponent<Animator>();
if (playerAnim != null)
{
    // On vérifie directement si le joueur N'EST PAS en train de bloquer
    if (!playerAnim.GetBool("IdleBlock"))
    {
        playerAnim.SetTrigger("hurt");
    }
}
                }
            }
        }

        void PlayAttackVoice()
        {
            if (audioSource != null && attackVoices != null && attackVoices.Length > 0)
            {
                AudioClip clip = attackVoices[Random.Range(0, attackVoices.Length)];
                if (clip != null)
                {
                    audioSource.PlayOneShot(clip);
                }
            }
        }

        protected override void ComputeVelocity()
        {
            if (move.x > 0.01f)
                spriteRenderer.flipX = false;
            else if (move.x < -0.01f)
                spriteRenderer.flipX = true;

            if (animator != null)
            {
                animator.SetBool("grounded", IsGrounded);
                
                bool isWalking = Mathf.Abs(move.x) > 0.01f;
                animator.SetBool("walk", isWalking);
            }

            targetVelocity = move * maxSpeed;
        }

        private void OnDrawGizmosSelected()
        {
            Gizmos.color = Color.red;
            Gizmos.DrawWireSphere(transform.position, attackDamageRadius);
        }
    }
}