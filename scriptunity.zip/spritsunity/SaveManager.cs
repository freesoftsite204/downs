using UnityEngine;
using UnityEngine.SceneManagement;

public class SaveManager : MonoBehaviour
{
    [Header("Joueur (Optionnel)")]
    public Transform playerTransform;

    private void Start()
    {
        // Au chargement de la scène, on applique la position sauvegardée si elle existe
        RestaurerPosition();
    }

    // Fonction à attribuer au bouton "Sauvegarder"
    public void Sauvegarder()
    {
        // 1. Sauvegarde du nom de la scène actuelle
        string currentSceneName = SceneManager.GetActiveScene().name;
        PlayerPrefs.SetString("SavedScene", currentSceneName);

        // 2. Sauvegarde de la position du joueur (si assigné)
        if (playerTransform != null)
        {
            PlayerPrefs.SetFloat("PlayerPosX", playerTransform.position.x);
            PlayerPrefs.SetFloat("PlayerPosY", playerTransform.position.y);
        }

        PlayerPrefs.Save();
        Debug.Log("Scène et position sauvegardées !");
    }

    // Fonction à attribuer au bouton "Charger"
    public void Charger()
    {
        if (PlayerPrefs.HasKey("SavedScene"))
        {
            string sceneToLoad = PlayerPrefs.GetString("SavedScene");
            SceneManager.LoadScene(sceneToLoad);
            Debug.Log("Chargement de la scène : " + sceneToLoad);
        }
        else
        {
            Debug.LogWarning("Aucune scène sauvegardée trouvée.");
        }
    }

    // Méthode interne pour appliquer la position sauvegardée
    private void RestaurerPosition()
    {
        if (playerTransform != null && PlayerPrefs.HasKey("PlayerPosX"))
        {
            float x = PlayerPrefs.GetFloat("PlayerPosX");
            float y = PlayerPrefs.GetFloat("PlayerPosY");

            // Gestion de la physique 2D si un Rigidbody2D est présent
            if (playerTransform.TryGetComponent<Rigidbody2D>(out Rigidbody2D rb))
            {
                rb.position = new Vector2(x, y);
                rb.velocity = Vector2.zero;
            }
            else
            {
                playerTransform.position = new Vector3(x, y, playerTransform.position.z);
            }

            Debug.Log("Position du joueur restaurée !");
        }
    }
}