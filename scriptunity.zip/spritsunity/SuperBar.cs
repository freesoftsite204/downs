using UnityEngine;
using UnityEngine.UI;

public class SuperBar : MonoBehaviour
{
    public Slider superSlider;

    [Header("Super")]
    public float maxSuper = 100f;
    public float superGainPerHit = 10f;

    private float currentSuper = 0f;

    private void Start()
    {
        currentSuper = 0f;

        superSlider.minValue = 0f;
        superSlider.maxValue = maxSuper;
        superSlider.value = currentSuper;
    }

    public void AddSuper(float amount)
    {
        currentSuper += amount;
        currentSuper = Mathf.Clamp(currentSuper, 0f, maxSuper);

        superSlider.value = currentSuper;
    }

    public void ResetSuper()
    {
        currentSuper = 0f;
        superSlider.value = currentSuper;
    }
}
