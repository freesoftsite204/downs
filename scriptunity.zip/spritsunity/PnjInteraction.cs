using System.Collections;
using UnityEngine;

public class PnjInteraction : MonoBehaviour
{
    [Header("Configuration UI")]
    [SerializeField] private GameObject textCanvasObject; // L'objet du texte (ou le panel) dans le Canvas
    [SerializeField] private float displayDuration = 10f;   // Durée d'affichage en secondes

    private Coroutine textCoroutine; // Permet de gérer les collisions répétées

    private void Start()
    {
        // On s'assure que le texte est caché au début du jeu
        if (textCanvasObject != null)
        {
            textCanvasObject.SetActive(false);
        }
    }

    private void OnTriggerEnter(Collider other)
    {
        // Debug pour vérifier qui touche le PNJ
        Debug.Log("Contact détecté avec : " + other.name + " (Tag: " + other.tag + ")");

        // Vérifie si c'est bien le joueur qui entre en contact
        if (other.CompareTag("Player"))
        {
            // Si une routine est déjà en cours, on l'arrête pour reset le timer de 3 secondes
            if (textCoroutine != null)
            {
                StopCoroutine(textCoroutine);
            }
            
            textCoroutine = StartCoroutine(ShowTextRoutine());
        }
    }

    private IEnumerator ShowTextRoutine()
    {
        // On affiche le texte
        textCanvasObject.SetActive(true);

        // On attend le temps défini
        yield return new WaitForSeconds(displayDuration);

        // On cache le texte
        textCanvasObject.SetActive(false);
        
        textCoroutine = null;
    }
}