using UnityEngine;

public class Combo1 : MonoBehaviour
{
    [Header("Composants")]
    [SerializeField] private Animator m_animator;

    [Header("Paramètres de combo")]
    [SerializeField] private float m_attackCooldown = 1f;
    [SerializeField] private float m_comboResetTime = 1.0f;

    private int m_currentAttack = 0;
    private float m_timeSinceAttack = 0.0f;

    // À lier si la roulade vient d'un autre script, sinon laisser à false
    public bool isRolling = false; 

    private void Awake()
    {
        if (m_animator == null)
            m_animator = GetComponent<Animator>();
    }

    private void Update()
    {
        // Incrémente le temps écoulé depuis la dernière attaque
        m_timeSinceAttack += Time.deltaTime;

        // Détection de la touche Y (JoystickButton3 sur Input Manager classique)
        if (Input.GetKeyDown(KeyCode.JoystickButton3) && m_timeSinceAttack > m_attackCooldown && !isRolling)
        {
            ExecuteAttack();
        }
    }

    private void ExecuteAttack()
    {
        m_currentAttack++;

        // Réinitialise le combo si le délai entre deux coups est trop long
        if (m_timeSinceAttack > m_comboResetTime || m_currentAttack > 3)
        {
            m_currentAttack = 1;
        }

        // Déclenche l'animation ("Attack1", "Attack2" ou "Attack3")
        m_animator.SetTrigger("Attack" + m_currentAttack);

        // Réinitialise le chrono
        m_timeSinceAttack = 0.0f;
    }
}