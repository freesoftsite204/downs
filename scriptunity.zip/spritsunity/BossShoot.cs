using UnityEngine;

public class BossShoot : MonoBehaviour
{
    [Header("Ajustements du Tir")]
    public GameObject bulletPrefab;
    public Transform firePoint;    
    public float bulletSpeed = 20f;
    public float fireRate = 1f; // Temps minimum entre deux tirs (en secondes)
    private float nextFireTime = 0f;

    [Header("Champ de Vision")]
    public float visionRange = 10f; // Distance max à laquelle le Boss peut voir le joueur
    public LayerMask obstacleLayer; // Optionnel : pour éviter que le boss tire à travers les murs

    private Animator animator;
    private SpriteRenderer bossSprite; // Renommé pour plus de clarté (c'est le sprite du Boss)

    void Start()
    {
        bossSprite = GetComponent<SpriteRenderer>();
        animator = GetComponent<Animator>();
    }

    void Update()
    {
        // On détermine la direction du regard du Boss basée sur son flipX
        Vector2 lookDirection = Vector2.right;
        if (bossSprite != null && bossSprite.flipX)
        {
            lookDirection = Vector2.left;
        }

        // On lance un rayon (Raycast) vers l'avant du Boss
        RaycastHit2D hit = Physics2D.Raycast(firePoint.position, lookDirection, visionRange);

        // On dessine le rayon dans l'éditeur de Unity pour pouvoir le visualiser et le debug
        Debug.DrawRay(firePoint.position, lookDirection * visionRange, Color.red);

        // Si le rayon touche quelque chose
        if (hit.collider != null)
        {
            // Si l'objet touché a le tag "Player" et que le Boss est prêt à tirer
            if (hit.collider.CompareTag("Player") && Time.time >= nextFireTime)
            {
                // On met à jour le moment du prochain tir autorisé
                nextFireTime = Time.time + fireRate;

                // On déclenche l'animation d'attaque
                if (animator != null)
                {
                    animator.SetTrigger("Attack");
                }

                // On appelle la fonction de tir
                Shoot();
            }
        }
    }

    void Shoot()
    {
        if (bulletPrefab == null || firePoint == null) return;

        GameObject bullet = Instantiate(bulletPrefab, firePoint.position, firePoint.rotation);
        Rigidbody2D rb = bullet.GetComponent<Rigidbody2D>();
       
        if (rb != null)
        {
            float direction = 1f;
           
            if (bossSprite != null && bossSprite.flipX)
            {
                direction = -1f; // On tire vers la gauche
            }

            // On applique la vitesse dans la bonne direction
            rb.linearVelocity = new Vector2(direction * bulletSpeed, 0);
           
            // On retourne aussi le visuel de la balle si elle va à gauche
            if (direction < 0) {
                bullet.transform.right = Vector3.left;
            }
        }
    }
}