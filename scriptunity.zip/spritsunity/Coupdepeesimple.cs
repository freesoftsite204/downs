using UnityEngine;

public class Coupdepeesimple : MonoBehaviour
{
    // Variables d'animation et d'audio
    [SerializeField] private Animator animator;
    [SerializeField] private AudioClip respawnAudio;
    [SerializeField] private AudioClip soundClip;
    [SerializeField] private AudioClip ouchAudio;
    public AudioSource audioSource;

    // Paramètres de combat
    [SerializeField] private float attackRadius = 5f;
    [SerializeField] private float knockbackForce = 4f;

    private void Start()
    {
        // Récupération automatique si non assigné dans l'inspecteur
        if (animator == null)
        {
            animator = GetComponent<Animator>();
        }

        if (audioSource == null)
        {
            audioSource = GetComponent<AudioSource>();
        }
    }

    private void Update()
    {
        if (Input.GetKeyDown(KeyCode.Joystick1Button2))
        {
            ExecuteAttack();
        }
    }

    private void ExecuteAttack()
    {
        if (animator != null)
        {
            animator.SetTrigger("Attack");
        }

        if (audioSource != null && soundClip != null)
        {
            audioSource.PlayOneShot(soundClip);
        }

        Debug.Log("Bouton pressé (Mode 2D) !");

        // Détection des cibles dans le rayon d'attaque
        Collider2D[] hitEnemies = Physics2D.OverlapCircleAll(transform.position, attackRadius);

        foreach (Collider2D hit in hitEnemies)
        {
            // --- Ennemi classique ---
            if (hit.CompareTag("Enemy"))
            {
                Animator enemyAnim = hit.GetComponent<Animator>();
                if (enemyAnim != null)
                {
                    enemyAnim.SetTrigger("destroy");
                }

                if (audioSource != null && respawnAudio != null)
                {
                    audioSource.PlayOneShot(respawnAudio);
                }

                // Désactivation du collider pour éviter les interactions multiples
                hit.enabled = false; 
                Destroy(hit.gameObject, 0.5f); 
            }
            // --- Boss ---
            else if (hit.CompareTag("Boss"))
            {
                if (ApplyDamageToBoss(hit))
                {
                    Animator bossAnim = hit.GetComponent<Animator>();
                    if (bossAnim != null)
                    {
                        bossAnim.SetTrigger("hurt3");
                    }

                    Rigidbody2D rb = hit.GetComponent<Rigidbody2D>();
                    if (rb != null)
                    {
                        Vector2 knockbackDirection = (hit.transform.position - transform.position).normalized;

                        if (knockbackDirection == Vector2.zero)
                        {
                            knockbackDirection = Vector2.up;
                        }

                        rb.velocity = knockbackDirection * knockbackForce;
                    }

                    if (audioSource != null && ouchAudio != null)
                    {
                        audioSource.PlayOneShot(ouchAudio);
                    }
                }
            }
        }
    }

    private bool ApplyDamageToBoss(Collider2D enemy)
    {
        // Recherche dynamique d'un composant possédant TakeDamage(int)
        var components = enemy.GetComponents<MonoBehaviour>();
        foreach (var comp in components)
        {
            var method = comp.GetType().GetMethod("TakeDamage", new[] { typeof(int) });
            if (method != null)
            {
                method.Invoke(comp, new object[] { 1 });
                return true;
            }
        }

        Debug.LogWarning("Boss détecté mais aucun script avec TakeDamage(int) trouvé !");
        return false;
    }

    // Visualisation du rayon d'attaque dans l'éditeur Unity
    private void OnDrawGizmosSelected()
    {
        Gizmos.color = Color.red;
        Gizmos.DrawWireSphere(transform.position, attackRadius);
    }
}