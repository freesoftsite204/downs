using UnityEngine;
using TMPro;

public class RankManager : MonoBehaviour
{
    public TextMeshProUGUI rankText;
    public TextMeshProUGUI winsText;

    [System.Serializable]
    public struct Rank
    {
        public string rankName;
        public int requiredWins;

        public Rank(string name, int wins)
        {
            rankName = name;
            requiredWins = wins;
        }
    }

    private static readonly Rank[] Ranks = new Rank[]
    {
        new Rank("Débutant", 0),
        new Rank("Novice I", 2),
        new Rank("Novice II", 5),
        new Rank("Apprenti", 10),
        new Rank("Intermédiaire", 15),
        new Rank("Confirmé", 25),
        new Rank("Avancé", 40),
        new Rank("Expert", 60),
        new Rank("Vétéran", 85),
        new Rank("Maître", 115),
        new Rank("Grand Maître", 150),
        new Rank("Pro", 200),
        new Rank("Élite", 260),
        new Rank("Champion", 330),
        new Rank("Légende", 410),
        new Rank("Mythique", 500),
        new Rank("Immortel", 600),
        new Rank("Divine", 720),
        new Rank("Titanesque", 850),
        new Rank("Absolu", 1000),
        new Rank("Seigneur de Guerre", 1200),
        new Rank("Monarque", 1500),
        new Rank("Transcendant", 2000)
    };

    private void Start()
    {
        UpdateRankUI();
    }

    public static void AddWin()
    {
        int wins = PlayerPrefs.GetInt("Victories", 0) + 1;
        PlayerPrefs.SetInt("Victories", wins);
        PlayerPrefs.Save();
    }

    /// <summary>
    /// Réinitialise les victoires à zéro en cas de défaite.
    /// </summary>
    public static void AddLoss()
    {
        PlayerPrefs.SetInt("Victories", 0);
        PlayerPrefs.Save();
    }

    public static int GetCurrentRankIndex(int wins)
    {
        for (int i = Ranks.Length - 1; i >= 0; i--)
        {
            if (wins >= Ranks[i].requiredWins)
            {
                return i;
            }
        }
        return 0;
    }

    public static string GetCurrentRank()
    {
        int wins = PlayerPrefs.GetInt("Victories", 0);
        int index = GetCurrentRankIndex(wins);
        return Ranks[index].rankName;
    }

    public void UpdateRankUI()
    {
        int wins = PlayerPrefs.GetInt("Victories", 0);

        if (rankText != null)
        {
            rankText.text = "Rang : " + GetCurrentRank();
        }

        if (winsText != null)
        {
            winsText.text = "Victoires : " + wins;
        }
    }
}