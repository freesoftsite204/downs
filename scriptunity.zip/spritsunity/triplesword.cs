using System.Collections;
using UnityEngine;
using Platformer.Mechanics; // Nécessaire pour accéder aux scripts d'IA Boss

public class TripleSword : MonoBehaviour
{
    // Variables d'animation et d'audio
    [SerializeField] private Animator animator;
    [SerializeField] private AudioClip respawnAudio;
    [SerializeField] private AudioClip soundClip;
    [SerializeField] private AudioClip ouchAudio;
    public AudioSource audioSource;

    // Paramètres de combat
    [SerializeField] private float attackRadius = 5f;
    [SerializeField] private float knockbackForce = 8f; // Augmenté si besoin pour rendre le knockback bien visible

    private void Start()
    {
        if (animator == null) animator = GetComponent<Animator>();
        if (audioSource == null) audioSource = GetComponent<AudioSource>();
    }

    private void Update()
    {
        if (Input.GetKeyDown(KeyCode.JoystickButton1))
        {
            ExecuteAttack();
        }
    }

    private void ExecuteAttack()
    {
        if (animator != null)
        {
            animator.SetTrigger("light");
        }

        if (audioSource != null && soundClip != null)
        {
            audioSource.PlayOneShot(soundClip);
        }

        Collider2D[] hitEnemies = Physics2D.OverlapCircleAll(transform.position, attackRadius);

        foreach (Collider2D hit in hitEnemies)
        {
            if (hit.CompareTag("Enemy"))
            {
                // Knockback pour les ennemis normaux
                Rigidbody2D rb = hit.GetComponent<Rigidbody2D>();
                if (rb != null)
                {
                    Vector2 knockbackDirection = (hit.transform.position - transform.position).normalized;
                    if (knockbackDirection == Vector2.zero)
                        knockbackDirection = Vector2.up;

                    rb.velocity = Vector2.zero;
                    rb.AddForce(knockbackDirection * knockbackForce, ForceMode2D.Impulse);
                }

                Animator enemyAnim = hit.GetComponent<Animator>();
                if (enemyAnim != null)
                {
                    enemyAnim.SetTrigger("destroy");
                }

                if (audioSource != null && respawnAudio != null)
                {
                    audioSource.PlayOneShot(respawnAudio);
                }

                hit.enabled = false;
                Destroy(hit.gameObject, 0.5f);
            }
            else if (hit.CompareTag("Boss"))
            {
                if (ApplyDamageToBoss(hit))
                {
                    Animator bossAnim = hit.GetComponent<Animator>();
                    if (bossAnim != null)
                    {
                        // Lance la coroutine qui gère l'impulsion physique et le verrouillage d'IA
                        StartCoroutine(LockBossDuringHurt3(bossAnim, hit.gameObject));
                    }

                    if (audioSource != null && ouchAudio != null)
                    {
                        audioSource.PlayOneShot(ouchAudio);
                    }
                }
            }
        }
    }

    private IEnumerator LockBossDuringHurt3(Animator bossAnim, GameObject bossObject)
    {
        // 1. Bloquer l'IA pour qu'elle n'envoie aucune commande de marche
        BossAIControllerdark2 dark2 = bossObject.GetComponent<BossAIControllerdark2>();
        BossAIControllerdark3 dark3 = bossObject.GetComponent<BossAIControllerdark3>();

        if (dark2 != null) dark2.isStunned = true;
        if (dark3 != null) dark3.isStunned = true;

        // 2. Déclencher l'animation hurt3
        bossAnim.SetTrigger("hurt3");

        // 3. Appliquer l'impulsion physique du knockback
        Rigidbody2D bossRb = bossObject.GetComponent<Rigidbody2D>();
        if (bossRb != null)
        {
            float directionX = bossObject.transform.position.x > transform.position.x ? 1f : -1f;
            Vector2 knockbackDir = new Vector2(directionX, 0.2f).normalized;

            bossRb.velocity = Vector2.zero;
            bossRb.AddForce(knockbackDir * knockbackForce, ForceMode2D.Impulse);
        }

        // 4. Attendre une frame pour s'assurer que l'animation a démarré dans l'Animator
        yield return null;

        // 5. Récupérer la durée de l'animation hurt3
        AnimatorStateInfo stateInfo = bossAnim.GetCurrentAnimatorStateInfo(0);
        float animationDuration = stateInfo.length;

        if (animationDuration <= 0.05f)
        {
            animationDuration = 0.6f;
        }

        // 6. Attendre la fin de l'animation (l'IA reste stunned pendant toute la durée)
        yield return new WaitForSeconds(animationDuration);

        // 7. Réactiver l'IA du boss
        if (dark2 != null) dark2.isStunned = false;
        if (dark3 != null) dark3.isStunned = false;

        bossAnim.ResetTrigger("hurt3");
    }

    private bool ApplyDamageToBoss(Collider2D enemy)
    {
        var components = enemy.GetComponents<MonoBehaviour>();
        foreach (var comp in components)
        {
            var method = comp.GetType().GetMethod("TakeDamage", new[] { typeof(int) });
            if (method != null)
            {
                method.Invoke(comp, new object[] { 1 });
                return true;
            }
        }

        Debug.LogWarning("Boss détecté mais aucun script avec TakeDamage(int) trouvé !");
        return false;
    }

    private void OnDrawGizmosSelected()
    {
        Gizmos.color = Color.red;
        Gizmos.DrawWireSphere(transform.position, attackRadius);
    }
}