using UnityEngine;
using UnityEngine.SceneManagement;

public class SelectionPersonnages : MonoBehaviour
{
    [Header("Configuration des Personnages")]
    [SerializeField] private GameObject[] personnagesP1; // Visuels/Prefabs du Joueur 1
    [SerializeField] private GameObject[] personnagesP2; // Visuels/Prefabs du Joueur 2

    private int indexP1 = 0;
    private int indexP2 = 0;

    private bool p1Valide = false;
    private bool p2Valide = false;

    // Protection contre le défilement trop rapide avec le stick analogique
    private bool axeP1Utilise = false;
    private bool axeP2Utilise = false;

    void Start()
    {
        ActualiserAffichageP1();
        ActualiserAffichageP2();
    }

    void Update()
    {
        GérerEntréesP1();
        GérerEntréesP2();

        // Si les deux joueurs ont validé, on passe à la scène de jeu
        if (p1Valide && p2Valide)
        {
            LancerPartie();
        }
    }

    // --- JOUEUR 1 ---
    private void GérerEntréesP1()
    {
        if (p1Valide) return;

        float axeX = Input.GetAxisRaw("Horizontal_P1"); // Utilise le joystick ou la croix P1

        if (axeX > 0.5f && !axeP1Utilise)
        {
            SuivantP1();
            axeP1Utilise = true;
        }
        else if (axeX < -0.5f && !axeP1Utilise)
        {
            PrecedentP1();
            axeP1Utilise = true;
        }
        else if (Mathf.Abs(axeX) < 0.2f)
        {
            axeP1Utilise = false;
        }

        if (Input.GetButtonDown("Submit_P1"))
        {
            p1Valide = true;
            Debug.Log("Joueur 1 a validé son personnage !");
        }
    }

    private void SuivantP1()
    {
        personnagesP1[indexP1].SetActive(false);
        indexP1 = (indexP1 + 1) % personnagesP1.Length;
        ActualiserAffichageP1();
    }

    private void PrecedentP1()
    {
        personnagesP1[indexP1].SetActive(false);
        indexP1--;
        if (indexP1 < 0) indexP1 = personnagesP1.Length - 1;
        ActualiserAffichageP1();
    }

    private void ActualiserAffichageP1()
    {
        if (personnagesP1.Length > 0)
            personnagesP1[indexP1].SetActive(true);
    }

    // --- JOUEUR 2 ---
    private void GérerEntréesP2()
    {
        if (p2Valide) return;

        float axeX = Input.GetAxisRaw("Horizontal_P2"); // Utilise le joystick ou la croix P2

        if (axeX > 0.5f && !axeP2Utilise)
        {
            SuivantP2();
            axeP2Utilise = true;
        }
        else if (axeX < -0.5f && !axeP2Utilise)
        {
            PrecedentP2();
            axeP2Utilise = true;
        }
        else if (Mathf.Abs(axeX) < 0.2f)
        {
            axeP2Utilise = false;
        }

        if (Input.GetButtonDown("Submit_P2"))
        {
            p2Valide = true;
            Debug.Log("Joueur 2 a validé son personnage !");
        }
    }

    private void SuivantP2()
    {
        personnagesP2[indexP2].SetActive(false);
        indexP2 = (indexP2 + 1) % personnagesP2.Length;
        ActualiserAffichageP2();
    }

    private void PrecedentP2()
    {
        personnagesP2[indexP2].SetActive(false);
        indexP2--;
        if (indexP2 < 0) indexP2 = personnagesP2.Length - 1;
        ActualiserAffichageP2();
    }

    private void ActualiserAffichageP2()
    {
        if (personnagesP2.Length > 0)
            personnagesP2[indexP2].SetActive(true);
    }

    // --- VALIDATION ET CHARGEMENT ---
    private void LancerPartie()
    {
        // Sauvegarde le choix des deux joueurs
        PlayerPrefs.SetInt("PersonnageChoisi_P1", indexP1);
        PlayerPrefs.SetInt("PersonnageChoisi_P2", indexP2);
        PlayerPrefs.Save();

        SceneManager.LoadScene("vplayervsblacknight");
    }
}