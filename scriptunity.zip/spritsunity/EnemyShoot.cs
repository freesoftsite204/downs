using UnityEngine;

public class EnemyShoot : MonoBehaviour
{
    public GameObject bulletPrefab; 
    public Transform firePoint;     
    public float bulletSpeed = 20f;
    
    [Header("Paramètres CPU")]
    public float fireRate = 2f; // Intervalle de tir en secondes
    private float nextFireTime = 0f;

    [Header("Cible")]
    public string playerTag = "Player";
    private Transform playerTransform;

    private Animator animator;
    private SpriteRenderer enemySprite;
    public AudioSource audioSource;
    public AudioClip soundClip;

    void Start()
    {
        enemySprite = GetComponent<SpriteRenderer>();
        animator = GetComponent<Animator>();

        // Recherche du joueur avec le tag "Player" au démarrage
        GameObject playerObj = GameObject.FindWithTag(playerTag);
        if (playerObj != null)
        {
            playerTransform = playerObj.transform;
        }
    }

    void Update()
    {
        // Si la référence au joueur est perdue (ex: respawn), on essaie de la retrouver
        if (playerTransform == null)
        {
            GameObject playerObj = GameObject.FindWithTag(playerTag);
            if (playerObj != null)
            {
                playerTransform = playerObj.transform;
            }
        }

        if (Time.time >= nextFireTime)
        {
            TriggerAttack();
            nextFireTime = Time.time + fireRate;
        }
    }

    void TriggerAttack()
    {
        if (animator != null)
        {
            animator.SetTrigger("bossattack2");
        }
        
        if (audioSource != null && soundClip != null)
        {
            audioSource.PlayOneShot(soundClip);
        }
        
        Shoot();
    }

    void Shoot()
    {
        if (bulletPrefab == null || firePoint == null || playerTransform == null) return;

        // Calcul de la direction vers le joueur
        Vector2 direction = (playerTransform.position - firePoint.position).normalized;

        // Oriente automatiquement le SpriteRenderer selon la position du joueur (gauche/droite)
        if (enemySprite != null)
        {
            enemySprite.flipX = direction.x < 0;
        }

        // Instanciation de la balle
        GameObject bullet = Instantiate(bulletPrefab, firePoint.position, Quaternion.identity);
        
        // Oriente le visuel de la balle vers la cible
        bullet.transform.right = direction;

        // Application de la vitesse
        Rigidbody2D rb = bullet.GetComponent<Rigidbody2D>();
        if (rb != null)
        {
            rb.linearVelocity = direction * bulletSpeed;
        }
    }
}