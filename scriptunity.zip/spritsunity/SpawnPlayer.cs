using UnityEngine;

public class SpawnPlayer : MonoBehaviour
{
    [Header("Liste des Prefabs de Personnages")]
    [SerializeField] private GameObject[] prefabsPersonnages;

    [Header("Point d'apparition")]
    [SerializeField] private Transform pointDApparition;

    void Start()
    {
        // Récupère l'index sélectionné (0 par défaut si non trouvé)
        int indexChoisi = PlayerPrefs.GetInt("PersonnageChoisi", 0);

        // Vérification de sécurité
        if (indexChoisi >= 0 && indexChoisi < prefabsPersonnages.Length)
        {
            Vector3 position = pointDApparition != null ? pointDApparition.position : Vector3.zero;
            Quaternion rotation = pointDApparition != null ? pointDApparition.rotation : Quaternion.identity;

            // Instancie le personnage choisi
            Instantiate(prefabsPersonnages[indexChoisi], position, rotation);
        }
        else
        {
            Debug.LogError("Index de personnage invalide ou tableau vide !");
        }
    }
}