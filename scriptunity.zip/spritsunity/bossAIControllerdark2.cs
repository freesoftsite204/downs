using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Platformer.Gameplay;
using static Platformer.Core.Simulation;
using Platformer.Model;
using Platformer.Core;

namespace Platformer.Mechanics
{
    public class BossAIControllerdark2 : KinematicObject
    {
        [Header("AI Settings")]
        public float maxSpeed = 3.5f;           
        public float attackDistance = 2f;       
        public float targetDetectionRadius = 10f; 
        public float attackDamageRadius = 2f;   
        public int damageAmount = 1;            

        [Header("Jump Settings")]
        public float jumpTakeOffSpeed = 7f;     // Force du saut
        public float minJumpInterval = 2f;      // Intervalle de temps min avant un saut
        public float maxJumpInterval = 5f;      // Intervalle de temps max avant un saut
        private float nextJumpTime = 0f;

        [Header("Attack Settings")]
        public float timeBetweenAttacks = 1.5f; // Temps en secondes entre chaque coup
        private float nextAttackTime = 0f;      // Chronomètre interne

        [Header("Audio Settings")]
        public AudioSource audioSource;
        public AudioClip voiceAttack1;
        public AudioClip voiceAttack2;
        public AudioClip voiceAttack3;

        private Transform playerTransform;
        private SpriteRenderer spriteRenderer;
        private Animator animator;
        private Vector2 move;
        private JumpState jumpState = JumpState.Grounded;

        public enum JumpState
        {
            Grounded,
            PrepareToJump,
            Jumping,
            InFlight
        }

        public bool isStunned = false;

        /// <summary>
        /// Bloque l'IA et les déplacements pendant toute la durée d'une animation (ex: "hurt3").
        /// </summary>
        public IEnumerator LockActionsForAnimation(string stateName)
        {
            isStunned = true;
            move.x = 0;
            
            // Attendre la fin de la frame pour s'assurer que l'animation a commencé dans l'Animator
            yield return null; 
            
            // Attendre la durée restante de l'état d'animation actuel
            AnimatorStateInfo stateInfo = animator.GetCurrentAnimatorStateInfo(0);
            if (stateInfo.IsName(stateName))
            {
                yield return new WaitForSeconds(stateInfo.length);
            }
            
            isStunned = false;
        }

        void Awake()
        {
            spriteRenderer = GetComponent<SpriteRenderer>();
            animator = GetComponent<Animator>();

            if (audioSource == null)
            {
                audioSource = GetComponent<AudioSource>();
            }

            ScheduleNextJump();
        }

        protected override void Update()
        {
            // Bloque le déplacement et les attaques si le boss est stun / subit un knockback
            if (isStunned)
            {
                move.x = 0;
                base.Update();
                return;
            }

            if (playerTransform == null)
            {
                GameObject playerObj = GameObject.FindGameObjectWithTag("Player");
                if (playerObj != null)
                {
                    playerTransform = playerObj.transform;
                }
            }

            if (playerTransform != null)
            {
                float distanceToPlayer = Vector2.Distance(transform.position, playerTransform.position);

                // Phase de poursuite
                if (distanceToPlayer <= targetDetectionRadius && distanceToPlayer > attackDistance)
                {
                    float direction = playerTransform.position.x > transform.position.x ? 1f : -1f;
                    move.x = direction;

                    // Déclenchement aléatoire du saut si au sol
                    if (IsGrounded && Time.time >= nextJumpTime)
                    {
                        jumpState = JumpState.PrepareToJump;
                        ScheduleNextJump();
                    }
                }
                // Phase d'attaque (proche du joueur)
                else
                {
                    move.x = 0; // S'arrêter pour attaquer

                    // Vérifie si la distance est bonne ET si le cooldown est écoulé
                    if (distanceToPlayer <= attackDistance && Time.time >= nextAttackTime)
                    {
                        TriggerAttack();
                        nextAttackTime = Time.time + timeBetweenAttacks;
                    }
                }
            }
            else
            {
                move.x = 0;
            }

            UpdateJumpState();
            base.Update();
        }

        void ScheduleNextJump()
        {
            nextJumpTime = Time.time + Random.Range(minJumpInterval, maxJumpInterval);
        }

        void UpdateJumpState()
        {
            switch (jumpState)
            {
                case JumpState.PrepareToJump:
                    jumpState = JumpState.Jumping;
                    break;

                case JumpState.Jumping:
                    if (!IsGrounded)
                    {
                        jumpState = JumpState.InFlight;
                    }
                    break;

                case JumpState.InFlight:
                    if (IsGrounded)
                    {
                        jumpState = JumpState.Grounded;
                    }
                    break;
            }
        }

        void TriggerAttack()
        {
            int randomAttack = Random.Range(1, 4);

            if (animator != null)
            {
                if (randomAttack == 1)
                {
                    animator.SetTrigger("bossattack");
                    PlayVoice(voiceAttack2);
                }
                else if (randomAttack == 2)
                {
                    animator.SetTrigger("bossAttack2");
                    PlayVoice(voiceAttack1);
                }
                else
                {
                    animator.SetTrigger("bossAttack3");
                    PlayVoice(voiceAttack3);
                }
            }
            
            Debug.Log("Le Boss attaque !");

            Collider2D[] hitPlayers = Physics2D.OverlapCircleAll(transform.position, attackDamageRadius);

            foreach (Collider2D playerCollider in hitPlayers)
            {
                if (playerCollider.CompareTag("Player"))
                {  
                    PlayerHealth playerHealth = playerCollider.GetComponent<PlayerHealth>();
                    if (playerHealth != null)
                    {
                        playerHealth.TakeDamage(damageAmount);
                    }
                    
                    Animator playerAnim = playerCollider.GetComponent<Animator>();
                    if (playerAnim != null)
                    {
                        if (!playerAnim.GetBool("IdleBlock"))
                        {
                            playerAnim.SetTrigger("hurt");
                        }
                    }
                }
            }
        }

        private void PlayVoice(AudioClip clip)
        {
            if (audioSource != null && clip != null)
            {
                audioSource.PlayOneShot(clip);
            }
        }

        protected override void ComputeVelocity()
        {
            // Verrouillage strict du mouvement au sol pendant l'état Stun
            if (isStunned)
            {
                move.x = 0;
                targetVelocity = Vector2.zero;
                if (animator != null)
                {
                    animator.SetBool("walk", false);
                }
                return;
            }

            if (jumpState == JumpState.Jumping)
            {
                velocity.y = jumpTakeOffSpeed;
            }

            if (move.x > 0.01f)
                spriteRenderer.flipX = false;
            else if (move.x < -0.01f)
                spriteRenderer.flipX = true;

            if (animator != null)
            {
                animator.SetBool("grounded", IsGrounded);
                bool isWalking = Mathf.Abs(move.x) > 0.01f;
                animator.SetBool("walk", isWalking);
            }

            targetVelocity = move * maxSpeed;
        }

        private void OnDrawGizmosSelected()
        {
            Gizmos.color = Color.red;
            Gizmos.DrawWireSphere(transform.position, attackDamageRadius);
        }
    }
}