using UnityEngine;

public class PlayerBlock : MonoBehaviour
{
    [Header("Composants")]
    [SerializeField] private Animator m_animator;

    // À lier à votre script de déplacement/roulade si besoin
    public bool isRolling = false;

    private bool m_isHoldingBlock = false;

    private void Awake()
    {
        if (m_animator == null)
            m_animator = GetComponent<Animator>();
    }

    private void Update()
    {
        // Quand on commence à maintenir LB (JoystickButton4)
        if (Input.GetKeyDown(KeyCode.JoystickButton4) && !isRolling)
        {
            m_isHoldingBlock = true;
            m_animator.SetTrigger("Block");
            m_animator.SetBool("IdleBlock", true);
        }

        // Tant que le bouton LB est maintenu appuyé
        if (Input.GetKey(KeyCode.JoystickButton4) && m_isHoldingBlock)
        {
            // S'assure que IdleBlock reste actif pendant tout le maintien
            m_animator.SetBool("IdleBlock", true);
        }

        // Dès qu'on relâche le bouton LB
        if (Input.GetKeyUp(KeyCode.JoystickButton4))
        {
            m_isHoldingBlock = false;
            m_animator.SetBool("IdleBlock", false);
        }
    }
}