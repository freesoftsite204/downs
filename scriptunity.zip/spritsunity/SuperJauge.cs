using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class SuperJauge : MonoBehaviour
{
    public static SuperJauge Instance; // Pour pouvoir l'appeler facilement depuis n'importe où

    [Header("Paramètres de la Jauge")]
    public int maxGauge = 3;
    public int currentGauge;

    [Header("UI")]
    public Slider superJaugeSlider;

    private void Awake()
    {
        // Singleton simple
        if (Instance == null)
            Instance = this;
        else
            Destroy(gameObject);
    }

    private void Start()
    {
        currentGauge = 0;

        if (superJaugeSlider != null)
        {
            superJaugeSlider.minValue = 0;
            superJaugeSlider.maxValue = maxGauge;
            superJaugeSlider.value = currentGauge;
        }
        else
        {
            Debug.LogWarning("Attention : Le SuperJaugeSlider n'est pas assigné dans l'inspecteur !");
        }
    }

    /// <summary>
    /// À appeler chaque fois qu'un ennemi prend des dégâts
    /// </summary>
    public void OnTakeDamage(int damage = 1)
    {
        currentGauge += damage;
        currentGauge = Mathf.Clamp(currentGauge, 0, maxGauge);

        if (superJaugeSlider != null)
            superJaugeSlider.value = currentGauge;

        if (currentGauge >= maxGauge)
            OnGaugeFull();
    }

    void OnGaugeFull()
    {
        SceneManager.LoadScene("playervsboss2");
    }
}