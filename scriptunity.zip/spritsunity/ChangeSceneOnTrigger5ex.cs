using UnityEngine;
using UnityEngine.SceneManagement;

public class ChangeSceneOnTrigger5ex : MonoBehaviour
{
    // Nom de la scène vers laquelle basculer
    public string levelboss1;

    private void OnTriggerEnter2D(Collider2D other)
    {
        // Vérifie que c’est bien le joueur
        if (other.CompareTag("Player"))
        {
            SceneManager.LoadScene("boss1");
        }
    }
}

