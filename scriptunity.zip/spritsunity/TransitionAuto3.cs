using UnityEngine;
using UnityEngine.SceneManagement;

public class TransitionAuto3 : MonoBehaviour
{
    [Header("Configuration")]
    [SerializeField] private string Level2 = "Level2"; // Nom exact de la scène suivante
    [SerializeField] private float tempsAttente = 7f;        // Temps en secondes

    void Start()
    {
        // On lance le compte à rebours dès que la scène de transition apparaît
        Invoke("ChangerDeScene", tempsAttente);
    }

    void ChangerDeScene()
    {
        SceneManager.LoadScene("MenuVs");
    }
}
