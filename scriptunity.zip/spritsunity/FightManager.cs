using UnityEngine;

public class FightManager : MonoBehaviour
{
    public TemporaryText temporaryText;

    void Start()
    {
        temporaryText.ShowText("FIGHT!");
    }
}