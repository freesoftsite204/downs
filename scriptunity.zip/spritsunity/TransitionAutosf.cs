using UnityEngine;
using UnityEngine.SceneManagement;

public class TransitionAutosf : MonoBehaviour
{
    [Header("Configuration")]
    [SerializeField] private string level3 = "level3"; // Nom exact de la scène suivante
    [SerializeField] private float tempsAttente = 7f;        // Temps en secondes

    void Start()
    {
        // On lance le compte à rebours dès que la scène de transition apparaît
        Invoke("ChangerDeScene", tempsAttente);
    }

    void ChangerDeScene()
    {
        SceneManager.LoadScene("level11a");
    }
}
