using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class BossHealthsuper2 : MonoBehaviour
{
    [Header("Paramètres de Santé")]
    [SerializeField] private int maxHealth = 3;
    private int currentHealth;

    [Header("Paramètres de Super")]
    [SerializeField] private int maxSuper = 100;
    private int currentSuper = 0;
    [SerializeField] private int superGainPerHit = 20;

    [Header("UI")]
    [SerializeField] private Slider healthSlider;
    [SerializeField] private Slider superSlider;

    private void Start()
    {
        currentHealth = maxHealth;

        // Configuration initiale des sliders
        if (healthSlider != null)
        {
            healthSlider.maxValue = maxHealth;
            UpdateHealthUI();
        }

        if (superSlider != null)
        {
            superSlider.maxValue = maxSuper;
            UpdateSuperUI();
        }
    }

    private void OnTriggerEnter2D(Collider2D other)
    {
        if (other.CompareTag("Enemy"))
        {
            TakeDamage(1);
        }
    }

    public void TakeDamage(int damage)
    {
        currentHealth = Mathf.Clamp(currentHealth - damage, 0, maxHealth);
        UpdateHealthUI();

        AddSuper(superGainPerHit);

        if (currentHealth <= 0)
        {
            Die();
        }
    }

    public void AddSuper(int amount)
    {
        currentSuper = Mathf.Min(currentSuper + amount, maxSuper);
        UpdateSuperUI();
    }

    private void UpdateHealthUI()
    {
        if (healthSlider != null)
        {
            healthSlider.value = currentHealth;
        }
    }

    private void UpdateSuperUI()
    {
        if (superSlider != null)
        {
            superSlider.value = currentSuper;
        }
    }

    private void Die()
    {
        SceneManager.LoadScene("playervsboss2");
    }
}