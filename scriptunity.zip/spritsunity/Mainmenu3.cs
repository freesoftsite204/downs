using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.EventSystems;
public class    Mainmenu3 : MonoBehaviour
{
   
    public GameObject jouer; 

    void Start()
    {
        // 2. Assurez-vous que rien n'est sélectionné
        EventSystem.current.SetSelectedGameObject(null);

        // 3. Définissez le premier bouton comme sélectionné
        EventSystem.current.SetSelectedGameObject(jouer);
    } 
    
    // Assurez-vous d'avoir une scène nommée "Niveau1" dans vos Build Settings
    public void LancerJeu()
    {
        SceneManager.LoadScene("MenuVs"); // Changez par le nom de votre première scène de jeu
    }

    public void QuitterJeu()
    {
        Debug.Log("Quitter le jeu...");
        Application.Quit(); // Fonctionne seulement dans une construction du jeu, pas dans l'éditeur
    }

    public void AfficherOptions()
    {
        // Logique pour afficher/cacher le panneau des options
        Debug.Log("Ouvrir le menu Options");
    }
}
