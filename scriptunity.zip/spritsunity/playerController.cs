using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Platformer.Gameplay;
using static Platformer.Core.Simulation;
using Platformer.Model;
using Platformer.Core;
using UnityEngine.InputSystem;

namespace Platformer.Mechanics
{
    /// <summary>
    /// Contrôleur du joueur : déplacement et saut.
    /// </summary>
    public class PlayerController : KinematicObject
    {
        [Header("Audio")]
        public AudioClip attackSoundClip;
        public AudioClip kickSoundClip;
        public AudioClip jumpAudio;
        public AudioClip respawnAudio;
        public AudioClip ouchAudio;

        [Header("Player Settings")]
        public float maxSpeed = 7f;
        public float jumpTakeOffSpeed = 7f;

        [Header("Attack Settings")]
        public float attack1Radius = 2f;
        public float attack4Radius = 5f;
        public float attackCooldown = 0.35f;          // anti-spam

        [Header("Knockback")]
        [SerializeField] private float knockbackForce = 10f;
        [SerializeField] private float stunDuration = 0.5f;

        public JumpState jumpState = JumpState.Grounded;
        public Collider2D collider2d;
        public AudioSource audioSource;
        public Health health;

        public bool controlEnabled = true;
        public bool isPlayerTwo = false;

        public Bounds Bounds => collider2d.bounds;

        // Privés
        private bool stopJump;
        private bool jump;
        private Vector2 move;
        private SpriteRenderer spriteRenderer;
        internal Animator animator;
        private float lastAttackTime = -10f;
        
        // Référence fixe à la manette assignée
        private Gamepad targetGamepad;

        readonly PlatformerModel model = Simulation.GetModel<PlatformerModel>();

        void Awake()
        {   
            // Attribution dynamique du tag selon le joueur
            gameObject.tag = isPlayerTwo ? "Player2" : "Player";

            health = GetComponent<Health>();
            audioSource = GetComponent<AudioSource>();
            collider2d = GetComponent<Collider2D>();
            spriteRenderer = GetComponent<SpriteRenderer>();
            animator = GetComponent<Animator>();
        }

        void Start()
        {
            AssignGamepad();
        }

        /// <summary>
        /// Assigne de manière fixe la manette en fonction du joueur
        /// </summary>
        public void AssignGamepad()
        {
            var gamepads = Gamepad.all;

            if (!isPlayerTwo && gamepads.Count > 0)
            {
                targetGamepad = gamepads[0]; // Manette 1 pour Joueur 1
            }
            else if (isPlayerTwo && gamepads.Count > 1)
            {
                targetGamepad = gamepads[1]; // Manette 2 pour Joueur 2
            }
        }

        protected override void Update()
        {
            // Tente de réassigner si la manette n'était pas disponible au Start
            if (targetGamepad == null)
            {
                AssignGamepad();
            }

            if (controlEnabled && targetGamepad != null)
            {
                // --- DÉPLACEMENT & SAUT ---
                move.x = targetGamepad.leftStick.x.ReadValue();

                // Bouton A / Croix pour sauter
                if (jumpState == JumpState.Grounded && targetGamepad.buttonSouth.wasPressedThisFrame)
                {
                    jumpState = JumpState.PrepareToJump;
                }
                else if (targetGamepad.buttonSouth.wasReleasedThisFrame)
                {
                    stopJump = true;
                    Schedule<PlayerStopJump>().player = this;
                }
            }
            else if (!controlEnabled)
            {
                move.x = 0;
            }

            UpdateJumpState();
            base.Update();
        }

        void UpdateJumpState()
        {
            jump = false;

            switch (jumpState)
            {
                case JumpState.PrepareToJump:
                    jumpState = JumpState.Jumping;
                    jump = true;
                    stopJump = false;
                    break;

                case JumpState.Jumping:
                    if (!IsGrounded)
                    {
                        Schedule<PlayerJumped>().player = this;
                        jumpState = JumpState.InFlight;
                    }
                    break;

                case JumpState.InFlight:
                    if (IsGrounded)
                    {
                        Schedule<PlayerLanded>().player = this;
                        jumpState = JumpState.Landed;
                    }
                    break;

                case JumpState.Landed:
                    jumpState = JumpState.Grounded;
                    break;
            }
        }

        protected override void ComputeVelocity()
        {
            if (jump && IsGrounded)
            {
                velocity.y = jumpTakeOffSpeed * model.jumpModifier;
                jump = false;
            }
            else if (stopJump)
            {
                stopJump = false;
                if (velocity.y > 0)
                    velocity.y *= model.jumpDeceleration;
            }

            // Flip du sprite
            if (move.x > 0.01f)
                spriteRenderer.flipX = false;
            else if (move.x < -0.01f)
                spriteRenderer.flipX = true;

            if (animator != null)
            {
                animator.SetBool("grounded", IsGrounded);
                animator.SetFloat("velocityX", Mathf.Abs(velocity.x) / maxSpeed);
            }

            targetVelocity = move * maxSpeed;
        }

        private void OnDrawGizmosSelected()
        {
            Gizmos.color = Color.red;
            Gizmos.DrawWireSphere(transform.position, attack1Radius);

            Gizmos.color = Color.yellow;
            Gizmos.DrawWireSphere(transform.position, attack4Radius);
        }

        public enum JumpState
        {
            Grounded,
            PrepareToJump,
            Jumping,
            InFlight,
            Landed
        }
    }
}