using UnityEngine;
using TMPro;
using System.Collections;

public class TemporaryText : MonoBehaviour
{
    public TextMeshProUGUI textUI;
    public float displayTime = 3f;

    private void Start()
    {
        textUI.gameObject.SetActive(false);
    }

    public void ShowText(string message)
    {
        StopAllCoroutines();
        StartCoroutine(DisplayText(message));
    }

    private IEnumerator DisplayText(string message)
    {
        textUI.text = message;
        textUI.gameObject.SetActive(true);

        yield return new WaitForSeconds(displayTime);

        textUI.gameObject.SetActive(false);
    }
}