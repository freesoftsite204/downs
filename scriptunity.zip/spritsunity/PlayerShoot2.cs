using UnityEngine;

public class PlayerShoot2 : MonoBehaviour
{
    public GameObject bulletPrefab; 
    public Transform firePoint;     
    public float bulletSpeed = 20f;
    private Animator animator;
    // Référence au SpriteRenderer pour savoir s'il est "flippé"
    private SpriteRenderer playerSprite;
    public AudioSource audioSource;
    // Glisse ton fichier audio (le bruit de l'attaque) ici
    public AudioClip soundClip;

    void Start()
    {
        // On récupère le SpriteRenderer au début
        playerSprite = GetComponent<SpriteRenderer>();
        animator = GetComponent<Animator>();
    }

   void Update()
    {
       if (Input.GetKeyDown(KeyCode.JoystickButton3))
{
    // On déclenche l'animation d'attaque
    if (animator != null)
    {
        animator.SetTrigger("bossattack2");
    }
    
    if (audioSource != null && soundClip != null)
    {
        // PlayOneShot permet de jouer le son sans couper une autre instance du son si tu appuies vite
        audioSource.PlayOneShot(soundClip);
    }
    
    Shoot();
}
    }

    void Shoot()
    {
        if (bulletPrefab == null || firePoint == null) return;

        GameObject bullet = Instantiate(bulletPrefab, firePoint.position, firePoint.rotation);
        Rigidbody2D rb = bullet.GetComponent<Rigidbody2D>();
        
        if (rb != null)
        {
            // On vérifie la direction basée sur le flipX du SpriteRenderer
            float direction = 1f;
            
            if (playerSprite != null && playerSprite.flipX)
            {
                direction = -1f; // On tire vers la gauche
            }

            // On applique la vitesse dans la bonne direction
            rb.linearVelocity = new Vector2(direction * bulletSpeed, 0);
            
            // Optionnel : On retourne aussi le visuel de la balle si elle va à gauche
            if (direction < 0) {
                bullet.transform.right = Vector3.left;
            }
        }
    }
}